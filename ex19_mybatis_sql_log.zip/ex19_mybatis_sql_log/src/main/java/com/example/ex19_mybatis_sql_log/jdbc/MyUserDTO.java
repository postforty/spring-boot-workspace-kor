package com.example.ex19_mybatis_sql_log.jdbc;

import lombok.Data;

@Data
public class MyUserDTO {
    private String id;
    private String name;
}
