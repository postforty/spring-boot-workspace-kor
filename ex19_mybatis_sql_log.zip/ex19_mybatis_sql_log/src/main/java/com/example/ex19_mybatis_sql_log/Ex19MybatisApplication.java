package com.example.ex19_mybatis_sql_log;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex19MybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex19MybatisApplication.class, args);
	}

}
