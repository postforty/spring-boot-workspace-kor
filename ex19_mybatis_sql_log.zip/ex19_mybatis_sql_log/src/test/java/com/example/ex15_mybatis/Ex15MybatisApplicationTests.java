package com.example.ex15_mybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex15MybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
