package com.example.ex31_jpa_qnaboard_rest_api_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex31JpaQnaboardRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex31JpaQnaboardRestApiApplication.class, args);
	}

}
