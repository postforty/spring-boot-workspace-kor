package com.example.ex31_jpa_qnaboard_rest_api_security.answer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer, Integer> {

}