package com.example.ex16_mybatis_board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex16MybatisBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
