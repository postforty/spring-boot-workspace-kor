package com.example.ex30_jpa_qnaboard_rest_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex30JpaQnaboardRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex30JpaQnaboardRestApiApplication.class, args);
	}

}
