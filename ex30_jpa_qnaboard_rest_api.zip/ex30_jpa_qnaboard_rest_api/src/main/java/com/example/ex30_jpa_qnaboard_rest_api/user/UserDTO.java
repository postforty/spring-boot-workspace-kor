package com.example.ex30_jpa_qnaboard_rest_api.user;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserDTO {

    private Long id;

    private String username;

    private String password;

    private String email;
}