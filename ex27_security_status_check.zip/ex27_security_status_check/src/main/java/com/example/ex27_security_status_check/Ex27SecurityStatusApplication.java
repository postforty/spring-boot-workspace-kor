package com.example.ex27_security_status_check;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex27SecurityStatusApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex27SecurityStatusApplication.class, args);
	}

}
